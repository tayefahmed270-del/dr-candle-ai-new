package com.drcandle.ai

import com.drcandle.ai.ai.LocalAnalysisEngine
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.CandlestickPattern
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.domain.TrendDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalAnalysisEngineTest {

    private val engine = LocalAnalysisEngine()
    private val btc = SupportedAssets.findBySymbol("BTC/USDT")

    @Test
    fun `returns failed status and no signal when candle count is below 30`() {
        val sparse = List(12) { idx ->
            Candle(1_000L * idx, 100.0, 102.0, 99.0, 101.0, 10.0)
        }
        val result = engine.analyze(btc, Timeframe.M1, sparse)
        assertEquals(EngineStatus.FAILED, result.status)
        assertEquals(SignalDirection.NO_SIGNAL, result.direction)
        assertEquals(0, result.confidencePercent)
    }

    @Test
    fun `detects bullish trend and indicators on uptrending candles`() {
        val candles = MutableList(45) { i ->
            val base = 50_000.0 + i * 45.0
            Candle(
                openTimeMs = 60_000L * i,
                open = base,
                high = base + 35.0,
                low = base - 10.0,
                close = base + 28.0,
                volume = 120.0
            )
        }
        // Add clear bullish engulfing at the end
        val last = candles.last()
        candles[candles.lastIndex - 1] = last.copy(open = last.close + 15.0, close = last.open)
        candles[candles.lastIndex] = last.copy(open = last.open - 5.0, close = last.close + 30.0)

        val result = engine.analyze(btc, Timeframe.M1, candles)
        assertEquals(EngineStatus.READY, result.status)
        assertNotNull(result.indicators)
        assertEquals(TrendDirection.BULLISH, result.indicators!!.trendDirection)
        assertTrue(result.indicators!!.ema9 > result.indicators!!.ema21)
        assertTrue(result.indicators!!.detectedPatterns.contains(CandlestickPattern.BULLISH_ENGULFING))
        assertEquals(SignalDirection.CALL, result.direction)
    }
}
