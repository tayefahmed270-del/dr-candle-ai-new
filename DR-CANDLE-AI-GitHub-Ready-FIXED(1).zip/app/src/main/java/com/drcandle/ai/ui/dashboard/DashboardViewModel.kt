package com.drcandle.ai.ui.dashboard

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drcandle.ai.data.AppContainer
import com.drcandle.ai.data.ScannerOverlayState
import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.CombinedSignal
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.TechnicalIndicators
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.market.MarketStreamEvent
import com.drcandle.ai.utils.Formatters
import com.drcandle.ai.utils.TerminalLogger
import com.example.R
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardUiState(
    val settings: AppSettings = AppSettings(),
    val activeAsset: MarketAsset = SupportedAssets.all.first(),
    val activeTimeframe: Timeframe = Timeframe.M1,
    val feedState: MarketFeedState = MarketFeedState.Idle,
    val candles: List<Candle> = emptyList(),
    val liveIndicators: TechnicalIndicators? = null,
    val latencyMs: Long = 0L,
    val lastUpdateMs: Long = 0L,
    val isAnalyzing: Boolean = false,
    val analysisProgress: Float = 0f,
    val geminiStatus: EngineStatus = EngineStatus.IDLE,
    val localStatus: EngineStatus = EngineStatus.IDLE,
    val geminiErrorNote: String? = null,
    val latestSignal: CombinedSignal? = null,
    val scannerState: ScannerOverlayState = ScannerOverlayState()
)

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)
    private var scanJob: Job? = null

    private val _state = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = combine(
        _state,
        container.settingsRepository.settingsFlow,
        container.scannerState
    ) { state, settings, scanner ->
        state.copy(
            settings = settings,
            activeAsset = SupportedAssets.findBySymbol(settings.selectedAssetSymbol),
            activeTimeframe = Timeframe.fromCode(settings.selectedTimeframeCode),
            scannerState = scanner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = DashboardUiState()
    )

    init {
        TerminalLogger.info("SYSTEM", "DR CANDLE AI quantum terminal initialized")
        observeMarketStream()
    }

    private fun observeMarketStream() {
        viewModelScope.launch {
            container.settingsRepository.settingsFlow
                .map { s ->
                    Triple(
                        SupportedAssets.findBySymbol(s.selectedAssetSymbol),
                        Timeframe.fromCode(s.selectedTimeframeCode),
                        Triple(s.twelveDataApiKey, s.customOtcFeedUrl, s.selectedAssetSymbol)
                    )
                }
                .distinctUntilChanged()
                .flatMapLatest { (asset, timeframe, _) ->
                    val currentSettings = uiState.value.settings
                    _state.update {
                        it.copy(
                            candles = emptyList(),
                            liveIndicators = null,
                            feedState = MarketFeedState.Connecting("Market Router"),
                            latencyMs = 0L
                        )
                    }
                    container.marketRepository.streamAsset(asset, timeframe, currentSettings)
                }
                .collect { event ->
                    when (event) {
                        is MarketStreamEvent.StateChanged -> {
                            _state.update { it.copy(feedState = event.state) }
                        }
                        is MarketStreamEvent.HistoricalSnapshot -> {
                            val asset = uiState.value.activeAsset
                            val tf = uiState.value.activeTimeframe
                            val localRes = container.localAnalysisEngine.analyze(asset, tf, event.candles)
                            _state.update {
                                it.copy(
                                    candles = event.candles,
                                    liveIndicators = localRes.indicators,
                                    latencyMs = event.latencyMs,
                                    lastUpdateMs = System.currentTimeMillis(),
                                    localStatus = localRes.status
                                )
                            }
                        }
                        is MarketStreamEvent.CandleUpdate -> {
                            val updatedCandles = mergeLiveCandle(_state.value.candles, event.candle)
                            val asset = uiState.value.activeAsset
                            val tf = uiState.value.activeTimeframe
                            val localRes = container.localAnalysisEngine.analyze(asset, tf, updatedCandles)
                            _state.update {
                                it.copy(
                                    candles = updatedCandles,
                                    liveIndicators = localRes.indicators,
                                    latencyMs = event.latencyMs,
                                    lastUpdateMs = System.currentTimeMillis(),
                                    localStatus = localRes.status
                                )
                            }
                        }
                    }
                }
        }
    }

    private fun mergeLiveCandle(current: List<Candle>, incoming: Candle): List<Candle> {
        if (current.isEmpty()) return listOf(incoming)
        val last = current.last()
        return when {
            last.openTimeMs == incoming.openTimeMs -> current.dropLast(1) + incoming
            incoming.openTimeMs > last.openTimeMs -> (current + incoming).takeLast(160)
            else -> current
        }
    }

    fun selectAsset(symbol: String) {
        viewModelScope.launch {
            container.settingsRepository.updateAsset(symbol)
        }
    }

    fun selectTimeframe(code: String) {
        viewModelScope.launch {
            container.settingsRepository.updateTimeframe(code)
        }
    }

    fun runDualAiAnalysis() {
        // Prevent duplicate concurrent scan requests
        if (scanJob?.isActive == true || _state.value.isAnalyzing) {
            TerminalLogger.warn("DUAL_AI", "Analysis already running; duplicate request ignored.")
            return
        }

        scanJob = viewModelScope.launch {
            val snapshotCandles = _state.value.candles
            val currentSettings = uiState.value.settings
            val asset = uiState.value.activeAsset
            val tf = uiState.value.activeTimeframe

            _state.update {
                it.copy(
                    isAnalyzing = true,
                    analysisProgress = 0.25f,
                    geminiStatus = EngineStatus.RUNNING,
                    localStatus = EngineStatus.RUNNING,
                    geminiErrorNote = null
                )
            }

            try {
                _state.update { it.copy(analysisProgress = 0.55f) }
                val combined = container.combinedAnalysisEngine.analyzeConcurrently(
                    asset = asset,
                    timeframe = tf,
                    candles = snapshotCandles,
                    settings = currentSettings
                )

                _state.update {
                    it.copy(
                        isAnalyzing = false,
                        analysisProgress = 1f,
                        geminiStatus = combined.geminiResult.status,
                        localStatus = combined.localResult.status,
                        geminiErrorNote = combined.geminiResult.errorMessage,
                        latestSignal = combined
                    )
                }

                // Persist every scan in Room Database
                container.historyRepository.saveSignal(combined)

                if (currentSettings.notificationsEnabled && combined.direction != SignalDirection.NO_SIGNAL) {
                    postSignalNotification(combined, asset.priceDecimals)
                }
            } catch (e: Exception) {
                TerminalLogger.err("DUAL_AI", "Unexpected analysis error: ${e.localizedMessage}")
                _state.update {
                    it.copy(
                        isAnalyzing = false,
                        analysisProgress = 0f,
                        geminiStatus = EngineStatus.FAILED,
                        geminiErrorNote = e.localizedMessage
                    )
                }
            }
        }
    }

    private fun postSignalNotification(signal: CombinedSignal, decimals: Int) {
        val ctx = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                ctx,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "dr_candle_signal_alerts"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                ctx.getString(R.string.alerts_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = ctx.getString(R.string.alerts_channel_description)
            }
            nm.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("${signal.assetSymbol} • ${signal.direction.label} (${signal.confidencePercent}%)")
            .setContentText("Entry ${Formatters.formatPrice(signal.entryPrice, decimals)} | ${signal.timeframeCode} | Exp ${signal.suggestedExpiryMinutes}m")
            .setAutoCancel(true)
            .build()

        nm.notify((System.currentTimeMillis() % 100_000).toInt(), notification)
    }
}
