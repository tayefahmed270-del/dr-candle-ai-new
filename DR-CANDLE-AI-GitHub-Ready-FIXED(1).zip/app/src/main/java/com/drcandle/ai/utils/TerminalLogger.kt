package com.drcandle.ai.utils

import com.drcandle.ai.domain.TerminalLogEntry
import com.drcandle.ai.domain.TerminalLogLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

object TerminalLogger {
    private const val MAX_LOGS = 250
    private val idGenerator = AtomicLong(1L)

    private val _logs = MutableStateFlow<List<TerminalLogEntry>>(emptyList())
    val logs: StateFlow<List<TerminalLogEntry>> = _logs.asStateFlow()

    fun log(tag: String, level: TerminalLogLevel, message: String) {
        val entry = TerminalLogEntry(
            id = idGenerator.getAndIncrement(),
            timestampMs = System.currentTimeMillis(),
            tag = tag,
            level = level,
            message = message
        )
        _logs.update { current ->
            (listOf(entry) + current).take(MAX_LOGS)
        }
    }

    fun info(tag: String, message: String) = log(tag, TerminalLogLevel.INFO, message)
    fun net(tag: String, message: String) = log(tag, TerminalLogLevel.NET, message)
    fun ws(tag: String, message: String) = log(tag, TerminalLogLevel.WS, message)
    fun ai(tag: String, message: String) = log(tag, TerminalLogLevel.AI, message)
    fun warn(tag: String, message: String) = log(tag, TerminalLogLevel.WARN, message)
    fun err(tag: String, message: String) = log(tag, TerminalLogLevel.ERR, message)

    fun clear() {
        _logs.value = emptyList()
        info("SYSTEM", "Terminal log buffer cleared.")
    }
}
