package com.drcandle.ai.ui.theme

import androidx.compose.ui.graphics.Color

object CyberColors {
    val ObsidianBg = Color(0xFF050A08)
    val AmoledBlack = Color(0xFF000000)
    val TerminalSurface = Color(0xFF09130F)
    val CardSurface = Color(0xFF0D1B15)
    val ElevatedSurface = Color(0xFF13261D)

    val NeonGreen = Color(0xFF00FF88)
    val ElectricEmerald = Color(0xFF00D672)
    val CyberCyan = Color(0xFF00E5FF)
    val PutCrimson = Color(0xFFFF3366)
    val WarningAmber = Color(0xFFFFB800)

    val TextPrimary = Color(0xFFE9FFF3)
    val TextSecondary = Color(0xFF88B89F)
    val TextMuted = Color(0xFF517865)

    val BorderSubtle = Color(0xFF1B3B2B)
    val BorderGlow = Color(0xFF00FF88)
    val GridLine = Color(0xFF132A1F)
}
