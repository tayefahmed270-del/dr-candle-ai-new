package com.drcandle.ai.domain

enum class AssetCategory(val label: String) {
    CRYPTO("CRYPTO"),
    GOLD("GOLD"),
    FOREX("FOREX"),
    OTC("OTC")
}

data class MarketAsset(
    val symbol: String,
    val displayName: String,
    val category: AssetCategory,
    val binanceSymbol: String? = null,
    val twelveDataSymbol: String? = null,
    val frankfurterBase: String? = null,
    val frankfurterQuote: String? = null,
    val priceDecimals: Int = 2,
    val isOtc: Boolean = false
)

object SupportedAssets {
    val all: List<MarketAsset> = listOf(
        MarketAsset(
            symbol = "BTC/USDT",
            displayName = "Bitcoin / Tether",
            category = AssetCategory.CRYPTO,
            binanceSymbol = "BTCUSDT",
            twelveDataSymbol = "BTC/USD",
            priceDecimals = 2
        ),
        MarketAsset(
            symbol = "ETH/USDT",
            displayName = "Ethereum / Tether",
            category = AssetCategory.CRYPTO,
            binanceSymbol = "ETHUSDT",
            twelveDataSymbol = "ETH/USD",
            priceDecimals = 2
        ),
        MarketAsset(
            symbol = "SOL/USDT",
            displayName = "Solana / Tether",
            category = AssetCategory.CRYPTO,
            binanceSymbol = "SOLUSDT",
            twelveDataSymbol = "SOL/USD",
            priceDecimals = 3
        ),
        MarketAsset(
            symbol = "BNB/USDT",
            displayName = "BNB / Tether",
            category = AssetCategory.CRYPTO,
            binanceSymbol = "BNBUSDT",
            twelveDataSymbol = "BNB/USD",
            priceDecimals = 2
        ),
        MarketAsset(
            symbol = "XAU/USD (PAXG)",
            displayName = "Gold Spot Tokenized (PAXG/USDT)",
            category = AssetCategory.GOLD,
            binanceSymbol = "PAXGUSDT",
            twelveDataSymbol = "XAU/USD",
            priceDecimals = 2
        ),
        MarketAsset(
            symbol = "XAU/USD",
            displayName = "Gold / US Dollar (Spot)",
            category = AssetCategory.GOLD,
            twelveDataSymbol = "XAU/USD",
            priceDecimals = 2
        ),
        MarketAsset(
            symbol = "EUR/USDT",
            displayName = "Euro / Tether (Live Spot)",
            category = AssetCategory.FOREX,
            binanceSymbol = "EURUSDT",
            twelveDataSymbol = "EUR/USD",
            priceDecimals = 4
        ),
        MarketAsset(
            symbol = "EUR/USD",
            displayName = "Euro / US Dollar",
            category = AssetCategory.FOREX,
            twelveDataSymbol = "EUR/USD",
            frankfurterBase = "EUR",
            frankfurterQuote = "USD",
            priceDecimals = 5
        ),
        MarketAsset(
            symbol = "GBP/USD",
            displayName = "British Pound / US Dollar",
            category = AssetCategory.FOREX,
            twelveDataSymbol = "GBP/USD",
            frankfurterBase = "GBP",
            frankfurterQuote = "USD",
            priceDecimals = 5
        ),
        MarketAsset(
            symbol = "USD/JPY",
            displayName = "US Dollar / Japanese Yen",
            category = AssetCategory.FOREX,
            twelveDataSymbol = "USD/JPY",
            frankfurterBase = "USD",
            frankfurterQuote = "JPY",
            priceDecimals = 3
        ),
        MarketAsset(
            symbol = "AUD/USD",
            displayName = "Australian Dollar / US Dollar",
            category = AssetCategory.FOREX,
            twelveDataSymbol = "AUD/USD",
            frankfurterBase = "AUD",
            frankfurterQuote = "USD",
            priceDecimals = 5
        ),
        MarketAsset(
            symbol = "EUR/USD (OTC)",
            displayName = "EUR/USD Quotex OTC",
            category = AssetCategory.OTC,
            priceDecimals = 5,
            isOtc = true
        ),
        MarketAsset(
            symbol = "GBP/USD (OTC)",
            displayName = "GBP/USD Quotex OTC",
            category = AssetCategory.OTC,
            priceDecimals = 5,
            isOtc = true
        )
    )

    fun findBySymbol(symbol: String): MarketAsset =
        all.firstOrNull { it.symbol == symbol } ?: all.first()
}

enum class Timeframe(
    val code: String,
    val binanceInterval: String,
    val twelveDataInterval: String,
    val durationMs: Long,
    val defaultExpiryMinutes: Int
) {
    M1("1m", "1m", "1min", 60_000L, 2),
    M5("5m", "5m", "5min", 300_000L, 5),
    M15("15m", "15m", "15min", 900_000L, 15),
    H1("1h", "1h", "1h", 3_600_000L, 30),
    H4("4h", "4h", "4h", 14_400_000L, 60);

    companion object {
        fun fromCode(code: String): Timeframe =
            entries.firstOrNull { it.code == code } ?: M1
    }
}

data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val isClosed: Boolean = true
)

sealed interface MarketFeedState {
    data object Idle : MarketFeedState
    data class Connecting(val sourceName: String) : MarketFeedState
    data class LiveWebSocket(val sourceName: String, val lastTickMs: Long) : MarketFeedState
    data class LiveRestFallback(val sourceName: String, val note: String, val lastTickMs: Long) : MarketFeedState
    data class Reconnecting(val sourceName: String, val attempt: Int, val reason: String) : MarketFeedState
    data class UnsupportedSource(val sourceName: String, val limitationMessage: String) : MarketFeedState
    data class Error(val sourceName: String, val message: String) : MarketFeedState
}

enum class CandlestickPattern(val label: String, val bias: SignalDirection) {
    BULLISH_ENGULFING("Bullish Engulfing", SignalDirection.CALL),
    BEARISH_ENGULFING("Bearish Engulfing", SignalDirection.PUT),
    HAMMER("Hammer", SignalDirection.CALL),
    SHOOTING_STAR("Shooting Star", SignalDirection.PUT),
    DOJI("Doji (Indecision)", SignalDirection.NO_SIGNAL),
    MORNING_STAR("Morning Star", SignalDirection.CALL),
    EVENING_STAR("Evening Star", SignalDirection.PUT),
    BULLISH_PIN_BAR("Bullish Pin Bar", SignalDirection.CALL),
    BEARISH_PIN_BAR("Bearish Pin Bar", SignalDirection.PUT)
}

enum class TrendDirection(val label: String) {
    BULLISH("BULLISH"),
    BEARISH("BEARISH"),
    SIDEWAYS("SIDEWAYS"),
    INSUFFICIENT_DATA("INSUFFICIENT DATA")
}

enum class VolatilityLevel(val label: String) {
    LOW("LOW"),
    MODERATE("MODERATE"),
    HIGH("HIGH"),
    EXTREME("EXTREME")
}

data class TechnicalIndicators(
    val ema9: Double,
    val ema21: Double,
    val ema9Series: List<Double>,
    val ema21Series: List<Double>,
    val rsi14: Double,
    val macdLine: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val bbUpperSeries: List<Double>,
    val bbLowerSeries: List<Double>,
    val atr14: Double,
    val volatilityPercent: Double,
    val volatilityLevel: VolatilityLevel,
    val momentumScore: Double, // -100.0 (strong bearish) to +100.0 (strong bullish)
    val trendDirection: TrendDirection,
    val supportLevels: List<Double>,
    val resistanceLevels: List<Double>,
    val detectedPatterns: List<CandlestickPattern>
)

enum class EngineStatus(val label: String) {
    IDLE("STANDBY"),
    RUNNING("ANALYZING"),
    READY("ONLINE"),
    FAILED("ERROR"),
    DEGRADED("PARTIAL")
}

enum class SignalDirection(val label: String) {
    CALL("CALL"),
    PUT("PUT"),
    NO_SIGNAL("NO SIGNAL")
}

data class LocalAnalysisResult(
    val direction: SignalDirection,
    val confidencePercent: Int,
    val indicators: TechnicalIndicators?,
    val reasoning: String,
    val durationMs: Long,
    val status: EngineStatus,
    val errorMessage: String? = null
)

data class GeminiAnalysisResult(
    val direction: SignalDirection,
    val confidencePercent: Int,
    val trendAnalysis: String,
    val patternRecognition: String,
    val indicatorInterpretation: String,
    val reasoning: String,
    val modelUsed: String,
    val durationMs: Long,
    val status: EngineStatus,
    val errorMessage: String? = null,
    val isRateLimited: Boolean = false
)

data class CombinedSignal(
    val assetSymbol: String,
    val direction: SignalDirection,
    val confidencePercent: Int,
    val entryPrice: Double,
    val suggestedExpiryMinutes: Int,
    val timeframeCode: String,
    val trendDirection: TrendDirection,
    val reasoning: String,
    val timestampMs: Long,
    val localResult: LocalAnalysisResult,
    val geminiResult: GeminiAnalysisResult,
    val dataCandleCount: Int,
    val isFromScreenScanner: Boolean = false
)

enum class TerminalLogLevel(val code: String) {
    INFO("INF"),
    NET("NET"),
    WS("WSS"),
    AI("AI "),
    WARN("WRN"),
    ERR("ERR")
}

data class TerminalLogEntry(
    val id: Long,
    val timestampMs: Long,
    val tag: String,
    val level: TerminalLogLevel,
    val message: String
)

enum class SignalOutcome(val label: String) {
    PENDING("PENDING"),
    WIN("WIN"),
    LOSS("LOSS"),
    SKIPPED("SKIPPED")
}

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    BENGALI("bn", "বাংলা")
}

data class AppSettings(
    val selectedAssetSymbol: String = "BTC/USDT",
    val selectedTimeframeCode: String = "1m",
    val customExpiryMinutes: Int = 2,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val notificationsEnabled: Boolean = true,
    val floatingScannerAutoSave: Boolean = true,
    val pureBlackAmoled: Boolean = false,
    val geminiModel: String = "gemini-3.8-flash",
    val customGeminiProxyUrl: String = "",
    val customGeminiApiKey: String = "",
    val twelveDataApiKey: String = "",
    val customOtcFeedUrl: String = ""
)
