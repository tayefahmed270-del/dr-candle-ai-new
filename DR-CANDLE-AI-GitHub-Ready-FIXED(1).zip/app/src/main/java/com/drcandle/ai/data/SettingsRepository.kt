package com.drcandle.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.drcandle.ai.domain.AppLanguage
import com.drcandle.ai.domain.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.drCandleDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "dr_candle_settings"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ASSET_SYMBOL = stringPreferencesKey("asset_symbol")
        val TIMEFRAME_CODE = stringPreferencesKey("timeframe_code")
        val CUSTOM_EXPIRY_MIN = intPreferencesKey("custom_expiry_min")
        val LANGUAGE = stringPreferencesKey("language")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val FLOATING_AUTO_SAVE = booleanPreferencesKey("floating_auto_save")
        val PURE_BLACK_AMOLED = booleanPreferencesKey("pure_black_amoled")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val CUSTOM_GEMINI_PROXY_URL = stringPreferencesKey("custom_gemini_proxy_url")
        val CUSTOM_GEMINI_API_KEY = stringPreferencesKey("custom_gemini_api_key")
        val TWELVE_DATA_API_KEY = stringPreferencesKey("twelve_data_api_key")
        val CUSTOM_OTC_FEED_URL = stringPreferencesKey("custom_otc_feed_url")
    }

    val settingsFlow: Flow<AppSettings> = context.drCandleDataStore.data.map { prefs ->
        AppSettings(
            selectedAssetSymbol = prefs[Keys.ASSET_SYMBOL] ?: "BTC/USDT",
            selectedTimeframeCode = prefs[Keys.TIMEFRAME_CODE] ?: "1m",
            customExpiryMinutes = prefs[Keys.CUSTOM_EXPIRY_MIN] ?: 2,
            language = if (prefs[Keys.LANGUAGE] == AppLanguage.BENGALI.code) AppLanguage.BENGALI else AppLanguage.ENGLISH,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            floatingScannerAutoSave = prefs[Keys.FLOATING_AUTO_SAVE] ?: true,
            pureBlackAmoled = prefs[Keys.PURE_BLACK_AMOLED] ?: false,
            geminiModel = prefs[Keys.GEMINI_MODEL] ?: "gemini-3.8-flash",
            customGeminiProxyUrl = prefs[Keys.CUSTOM_GEMINI_PROXY_URL] ?: "",
            customGeminiApiKey = prefs[Keys.CUSTOM_GEMINI_API_KEY] ?: "",
            twelveDataApiKey = prefs[Keys.TWELVE_DATA_API_KEY] ?: "",
            customOtcFeedUrl = prefs[Keys.CUSTOM_OTC_FEED_URL] ?: ""
        )
    }

    suspend fun updateAsset(symbol: String) {
        context.drCandleDataStore.edit { it[Keys.ASSET_SYMBOL] = symbol }
    }

    suspend fun updateTimeframe(code: String) {
        context.drCandleDataStore.edit { it[Keys.TIMEFRAME_CODE] = code }
    }

    suspend fun updateCustomExpiry(minutes: Int) {
        context.drCandleDataStore.edit { it[Keys.CUSTOM_EXPIRY_MIN] = minutes.coerceIn(1, 240) }
    }

    suspend fun updateLanguage(language: AppLanguage) {
        context.drCandleDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        context.drCandleDataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun updateFloatingAutoSave(enabled: Boolean) {
        context.drCandleDataStore.edit { it[Keys.FLOATING_AUTO_SAVE] = enabled }
    }

    suspend fun updatePureBlackAmoled(enabled: Boolean) {
        context.drCandleDataStore.edit { it[Keys.PURE_BLACK_AMOLED] = enabled }
    }

    suspend fun updateGeminiModel(model: String) {
        context.drCandleDataStore.edit { it[Keys.GEMINI_MODEL] = model }
    }

    suspend fun updateCustomGeminiProxyUrl(url: String) {
        context.drCandleDataStore.edit { it[Keys.CUSTOM_GEMINI_PROXY_URL] = url.trim() }
    }

    suspend fun updateCustomGeminiApiKey(key: String) {
        context.drCandleDataStore.edit { it[Keys.CUSTOM_GEMINI_API_KEY] = key.trim() }
    }

    suspend fun updateTwelveDataApiKey(key: String) {
        context.drCandleDataStore.edit { it[Keys.TWELVE_DATA_API_KEY] = key.trim() }
    }

    suspend fun updateCustomOtcFeedUrl(url: String) {
        context.drCandleDataStore.edit { it[Keys.CUSTOM_OTC_FEED_URL] = url.trim() }
    }
}
