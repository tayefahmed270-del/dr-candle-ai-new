package com.drcandle.ai.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drcandle.ai.data.AppContainer
import com.drcandle.ai.domain.AppLanguage
import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DiagnosticsReport(
    val isRunning: Boolean = false,
    val marketStatus: String = "Not tested",
    val geminiStatus: String = "Not tested",
    val latencyMs: Long? = null
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val container = AppContainer.getInstance(application)
    private val repo = container.settingsRepository

    val settings: StateFlow<AppSettings> = repo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = AppSettings()
    )

    private val _diagnostics = MutableStateFlow(DiagnosticsReport())
    val diagnostics: StateFlow<DiagnosticsReport> = _diagnostics.asStateFlow()

    fun updateAsset(symbol: String) = viewModelScope.launch { repo.updateAsset(symbol) }
    fun updateTimeframe(code: String) = viewModelScope.launch { repo.updateTimeframe(code) }
    fun updateExpiry(minutes: Int) = viewModelScope.launch { repo.updateCustomExpiry(minutes) }
    fun updateLanguage(lang: AppLanguage) = viewModelScope.launch { repo.updateLanguage(lang) }
    fun updateNotifications(enabled: Boolean) = viewModelScope.launch { repo.updateNotificationsEnabled(enabled) }
    fun updateFloatingAutoSave(enabled: Boolean) = viewModelScope.launch { repo.updateFloatingAutoSave(enabled) }
    fun updatePureBlackAmoled(enabled: Boolean) = viewModelScope.launch { repo.updatePureBlackAmoled(enabled) }
    fun updateGeminiModel(model: String) = viewModelScope.launch { repo.updateGeminiModel(model) }

    fun saveApiConfigs(
        proxyUrl: String,
        geminiApiKey: String,
        twelveDataKey: String,
        otcFeedUrl: String
    ) {
        viewModelScope.launch {
            repo.updateCustomGeminiProxyUrl(proxyUrl)
            repo.updateCustomGeminiApiKey(geminiApiKey)
            repo.updateTwelveDataApiKey(twelveDataKey)
            repo.updateCustomOtcFeedUrl(otcFeedUrl)
            TerminalLogger.info("SETTINGS", "Updated API and provider configurations")
        }
    }

    fun runConnectionDiagnostics() {
        viewModelScope.launch {
            _diagnostics.value = DiagnosticsReport(isRunning = true, marketStatus = "Testing feed...", geminiStatus = "Checking engine...")
            val current = repo.settingsFlow.first()
            val asset = SupportedAssets.findBySymbol(current.selectedAssetSymbol)
            val tf = Timeframe.fromCode(current.selectedTimeframeCode)

            val marketResult = container.marketRepository.testProviderConnectivity(asset, tf, current)
            val marketSummary = marketResult.fold(
                onSuccess = { (candles, lat) -> "OK (${candles.size} candles, ${lat}ms)" },
                onFailure = { err -> "FAILED: ${err.localizedMessage}" }
            )
            val latency = marketResult.getOrNull()?.second

            val geminiMode = when {
                current.customGeminiProxyUrl.isNotBlank() -> "Custom Proxy (${current.geminiModel})"
                current.customGeminiApiKey.isNotBlank() -> "Custom Key (${current.geminiModel})"
                else -> "Firebase AI Logic + App Check (${current.geminiModel})"
            }

            _diagnostics.value = DiagnosticsReport(
                isRunning = false,
                marketStatus = marketSummary,
                geminiStatus = geminiMode,
                latencyMs = latency
            )
        }
    }
}
