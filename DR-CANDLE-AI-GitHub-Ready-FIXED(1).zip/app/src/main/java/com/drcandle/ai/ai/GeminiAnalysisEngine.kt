package com.drcandle.ai.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.GeminiAnalysisResult
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.TechnicalIndicators
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.network.NetworkModule
import com.drcandle.ai.utils.Formatters
import com.drcandle.ai.utils.TerminalLogger
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class GeminiAnalysisEngine {

    companion object {
        private const val TAG = "GeminiAnalysisEngine"
        private const val TIMEOUT_MS = 60_000L
        val SUPPORTED_MODELS = listOf(
            "gemini-3.8-flash",
            "gemini-3.5-flash-lite",
            "gemini-4-argon"
        )
    }

    private val signalSchema = Schema.obj(
        properties = mapOf(
            "direction" to Schema.enumeration(
                values = listOf("CALL", "PUT", "NO_SIGNAL"),
                description = "Recommended binary/short-term directional bias or NO_SIGNAL if unclear"
            ),
            "confidencePercent" to Schema.integer(
                description = "Technical alignment score from 0 to 95 (never 100 or guaranteed)"
            ),
            "trendAnalysis" to Schema.string(
                description = "Concise market structure and trend assessment"
            ),
            "patternRecognition" to Schema.string(
                description = "Candlestick formation and price action observation"
            ),
            "indicatorInterpretation" to Schema.string(
                description = "Interpretation of EMA 9/21, RSI 14, MACD, Bollinger Bands, and S/R"
            ),
            "reasoning" to Schema.string(
                description = "Clear 2-3 sentence technical synthesis explaining why CALL, PUT, or NO_SIGNAL"
            )
        )
    )

    private fun buildFirebaseModel(modelName: String) = Firebase.ai.generativeModel(
        modelName = modelName.ifBlank { "gemini-3.8-flash" },
        generationConfig = generationConfig {
            responseMimeType = "application/json"
            responseSchema = signalSchema
            temperature = 0.2f
        }
    )

    suspend fun analyzeMarketData(
        asset: MarketAsset,
        timeframe: Timeframe,
        candles: List<Candle>,
        indicators: TechnicalIndicators?,
        settings: AppSettings
    ): GeminiAnalysisResult {
        val startMs = System.currentTimeMillis()
        val modelName = settings.geminiModel.ifBlank { "gemini-3.8-flash" }
        val prompt = buildMarketPrompt(asset, timeframe, candles, indicators, settings.language.displayName)

        return executeTextOrProxy(
            modelName = modelName,
            prompt = prompt,
            settings = settings,
            startMs = startMs
        )
    }

    suspend fun analyzeChartScreenshot(
        bitmap: Bitmap,
        assetLabel: String,
        timeframeCode: String,
        settings: AppSettings
    ): GeminiAnalysisResult {
        val startMs = System.currentTimeMillis()
        val modelName = settings.geminiModel.ifBlank { "gemini-3.8-flash" }

        val prompt = """
            You are DR CANDLE AI, a precision technical chart analyst.
            Analyze the attached trading chart screenshot (context asset: $assetLabel, timeframe: $timeframeCode).
            Inspect visible candlesticks, wicks, momentum, support/resistance, and trendlines.
            Rules:
            - Output CALL only if clear bullish structure/reversal confluence is visible.
            - Output PUT only if clear bearish structure/reversal confluence is visible.
            - Output NO_SIGNAL if the chart is blurry, not a candlestick chart, or direction is indecisive.
            - Never guarantee profits. Confidence is technical alignment (0-95).
            Respond in ${settings.language.displayName} for text fields while keeping direction enum exact.
        """.trimIndent()

        return try {
            val rawJson = withTimeout(TIMEOUT_MS) {
                val proxyUrl = settings.customGeminiProxyUrl.trim()
                val customKey = settings.customGeminiApiKey.trim()
                when {
                    proxyUrl.isNotEmpty() -> callCustomProxyWithImage(proxyUrl, modelName, prompt, bitmap)
                    customKey.isNotEmpty() -> callDirectGeminiRestWithImage(customKey, modelName, prompt, bitmap)
                    else -> {
                        val model = buildFirebaseModel(modelName)
                        val response = model.generateContent(
                            content {
                                image(bitmap)
                                text(prompt)
                            }
                        )
                        response.text ?: throw IllegalStateException("Firebase AI returned an empty response.")
                    }
                }
            }
            parseJsonToResult(rawJson, modelName, startMs)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini screenshot analysis timed out", e)
            TerminalLogger.err("GEMINI_AI", "Vision request timed out after 60s")
            failedResult(modelName, startMs, "Gemini vision timed out after 60 seconds.", isRateLimited = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "Gemini vision failed"
            val rateLimited = msg.contains("429") || msg.contains("quota", ignoreCase = true) || msg.contains("rate", ignoreCase = true)
            Log.e(TAG, "Gemini screenshot analysis failed", e)
            TerminalLogger.err("GEMINI_AI", "Vision error: $msg")
            failedResult(modelName, startMs, msg, isRateLimited = rateLimited)
        }
    }

    private suspend fun executeTextOrProxy(
        modelName: String,
        prompt: String,
        settings: AppSettings,
        startMs: Long
    ): GeminiAnalysisResult {
        return try {
            val rawJson = withTimeout(TIMEOUT_MS) {
                val proxyUrl = settings.customGeminiProxyUrl.trim()
                val customKey = settings.customGeminiApiKey.trim()
                when {
                    proxyUrl.isNotEmpty() -> {
                        TerminalLogger.ai("GEMINI_AI", "Routing inference via configured backend proxy -> $modelName")
                        callCustomProxyText(proxyUrl, modelName, prompt)
                    }
                    customKey.isNotEmpty() -> {
                        TerminalLogger.ai("GEMINI_AI", "Routing inference via user-configured Gemini key -> $modelName")
                        callDirectGeminiRestText(customKey, modelName, prompt)
                    }
                    else -> {
                        TerminalLogger.ai("GEMINI_AI", "Invoking Firebase AI Logic ($modelName) via App Check")
                        val model = buildFirebaseModel(modelName)
                        val response = model.generateContent(prompt)
                        response.text ?: throw IllegalStateException("Gemini returned an empty response.")
                    }
                }
            }
            parseJsonToResult(rawJson, modelName, startMs)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini inference timed out", e)
            TerminalLogger.err("GEMINI_AI", "Request timed out after 60s")
            failedResult(modelName, startMs, "Gemini analysis timed out after 60 seconds.", isRateLimited = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "Gemini inference failed"
            val rateLimited = msg.contains("429") || msg.contains("quota", ignoreCase = true) || msg.contains("rate", ignoreCase = true)
            Log.e(TAG, "Gemini inference failed", e)
            TerminalLogger.err("GEMINI_AI", "Error: $msg")
            failedResult(modelName, startMs, msg, isRateLimited = rateLimited)
        }
    }

    private fun parseJsonToResult(
        rawJson: String,
        modelName: String,
        startMs: Long
    ): GeminiAnalysisResult {
        val json = JSONObject(rawJson)
        val dirRaw = json.optString("direction", "NO_SIGNAL").uppercase()
        val direction = when (dirRaw) {
            "CALL" -> SignalDirection.CALL
            "PUT" -> SignalDirection.PUT
            else -> SignalDirection.NO_SIGNAL
        }
        val confidence = json.optInt("confidencePercent", 0).coerceIn(0, 95)
        val trend = json.optString("trendAnalysis", "No trend summary provided.")
        val pattern = json.optString("patternRecognition", "No dominant pattern identified.")
        val indicatorInterp = json.optString("indicatorInterpretation", "No indicator note.")
        val reasoning = json.optString("reasoning", "No reasoning provided.")
        val duration = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)

        TerminalLogger.ai("GEMINI_AI", "Completed $modelName -> ${direction.label} (${confidence}%) in ${duration}ms")

        return GeminiAnalysisResult(
            direction = direction,
            confidencePercent = confidence,
            trendAnalysis = trend,
            patternRecognition = pattern,
            indicatorInterpretation = indicatorInterp,
            reasoning = reasoning,
            modelUsed = modelName,
            durationMs = duration,
            status = EngineStatus.READY
        )
    }

    private fun failedResult(
        modelName: String,
        startMs: Long,
        error: String,
        isRateLimited: Boolean
    ): GeminiAnalysisResult = GeminiAnalysisResult(
        direction = SignalDirection.NO_SIGNAL,
        confidencePercent = 0,
        trendAnalysis = "Unavailable",
        patternRecognition = "Unavailable",
        indicatorInterpretation = "Unavailable",
        reasoning = error,
        modelUsed = modelName,
        durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
        status = EngineStatus.FAILED,
        errorMessage = error,
        isRateLimited = isRateLimited
    )

    private fun buildMarketPrompt(
        asset: MarketAsset,
        timeframe: Timeframe,
        candles: List<Candle>,
        indicators: TechnicalIndicators?,
        languageLabel: String
    ): String {
        val recent = candles.takeLast(15).joinToString("\n") { c ->
            "O=${Formatters.formatPrice(c.open, asset.priceDecimals)} " +
                "H=${Formatters.formatPrice(c.high, asset.priceDecimals)} " +
                "L=${Formatters.formatPrice(c.low, asset.priceDecimals)} " +
                "C=${Formatters.formatPrice(c.close, asset.priceDecimals)}"
        }
        val indBlock = if (indicators != null) {
            """
            EMA9=${Formatters.formatPrice(indicators.ema9, asset.priceDecimals)}, EMA21=${Formatters.formatPrice(indicators.ema21, asset.priceDecimals)}
            RSI14=${Formatters.formatPrice(indicators.rsi14, 2)}
            MACD=${Formatters.formatPrice(indicators.macdLine, asset.priceDecimals + 2)}, Signal=${Formatters.formatPrice(indicators.macdSignal, asset.priceDecimals + 2)}, Hist=${Formatters.formatPrice(indicators.macdHistogram, asset.priceDecimals + 2)}
            Bollinger Upper=${Formatters.formatPrice(indicators.bbUpper, asset.priceDecimals)}, Mid=${Formatters.formatPrice(indicators.bbMiddle, asset.priceDecimals)}, Lower=${Formatters.formatPrice(indicators.bbLower, asset.priceDecimals)}
            Volatility=${Formatters.formatPercent(indicators.volatilityPercent)} (${indicators.volatilityLevel.label})
            Trend=${indicators.trendDirection.label}, MomentumScore=${indicators.momentumScore.toInt()}
            Patterns=${indicators.detectedPatterns.joinToString { it.label }.ifEmpty { "None" }}
            Support=${indicators.supportLevels.joinToString { Formatters.formatPrice(it, asset.priceDecimals) }.ifEmpty { "N/A" }}
            Resistance=${indicators.resistanceLevels.joinToString { Formatters.formatPrice(it, asset.priceDecimals) }.ifEmpty { "N/A" }}
            """.trimIndent()
        } else {
            "Indicators unavailable."
        }

        return """
            You are DR CANDLE AI, a disciplined quantitative technical analyst.
            Evaluate genuine live OHLC market data for ${asset.symbol} on the ${timeframe.code} timeframe.
            
            Technical Indicators:
            $indBlock
            
            Latest 15 Candles (oldest to newest):
            $recent
            
            Rules:
            - Output CALL if multi-indicator & price-action confluence strongly favors upside continuation/reversal.
            - Output PUT if multi-indicator & price-action confluence strongly favors downside continuation/reversal.
            - Output NO_SIGNAL if signals conflict, volatility is erratic, or edge is weak.
            - Never promise guaranteed wins. Confidence (0-95) reflects indicator alignment only.
            Write trendAnalysis, patternRecognition, indicatorInterpretation, and reasoning in $languageLabel.
        """.trimIndent()
    }

    private suspend fun callCustomProxyText(proxyUrl: String, modelName: String, prompt: String): String =
        withContext(Dispatchers.IO) {
            val payload = JSONObject().apply {
                put("model", modelName)
                put("prompt", prompt)
            }
            val request = Request.Builder()
                .url(proxyUrl)
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            NetworkModule.okHttpClient.newCall(request).execute().use { res ->
                if (!res.isSuccessful) throw IllegalStateException("Proxy HTTP ${res.code}: ${res.message}")
                res.body?.string() ?: throw IllegalStateException("Empty proxy response")
            }
        }

    private suspend fun callCustomProxyWithImage(
        proxyUrl: String,
        modelName: String,
        prompt: String,
        bitmap: Bitmap
    ): String = withContext(Dispatchers.IO) {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos)
        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("model", modelName)
            put("prompt", prompt)
            put("imageBase64", b64)
        }
        val request = Request.Builder()
            .url(proxyUrl)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        NetworkModule.okHttpClient.newCall(request).execute().use { res ->
            if (!res.isSuccessful) throw IllegalStateException("Proxy HTTP ${res.code}: ${res.message}")
            res.body?.string() ?: throw IllegalStateException("Empty proxy response")
        }
    }

    private suspend fun callDirectGeminiRestText(apiKey: String, modelName: String, prompt: String): String =
        withContext(Dispatchers.IO) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val bodyJson = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                put(
                    "generationConfig",
                    JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("temperature", 0.2)
                    }
                )
            }
            executeGeminiRestCall(url, bodyJson)
        }

    private suspend fun callDirectGeminiRestWithImage(
        apiKey: String,
        modelName: String,
        prompt: String,
        bitmap: Bitmap
    ): String = withContext(Dispatchers.IO) {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos)
        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", b64)
                )
            )
        val bodyJson = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            put(
                "generationConfig",
                JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.2)
                }
            )
        }
        executeGeminiRestCall(url, bodyJson)
    }

    private fun executeGeminiRestCall(url: String, bodyJson: JSONObject): String {
        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()
        NetworkModule.okHttpClient.newCall(request).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            if (res.code == 429) {
                throw IllegalStateException("HTTP 429 Rate limit exceeded on custom Gemini API key.")
            }
            if (!res.isSuccessful) {
                throw IllegalStateException("Gemini REST HTTP ${res.code}: $raw")
            }
            val root = JSONObject(raw)
            return root.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
