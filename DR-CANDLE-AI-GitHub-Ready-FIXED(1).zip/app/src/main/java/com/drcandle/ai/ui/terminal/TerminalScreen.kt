package com.drcandle.ai.ui.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.TerminalLogLevel
import com.drcandle.ai.ui.AppStrings
import com.drcandle.ai.ui.dashboard.DashboardUiState
import com.drcandle.ai.ui.theme.CyberCard
import com.drcandle.ai.ui.theme.CyberColors
import com.drcandle.ai.utils.Formatters
import com.drcandle.ai.utils.TerminalLogger

@Composable
fun TerminalScreen(
    dashboardState: DashboardUiState,
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val logs by TerminalLogger.logs.collectAsStateWithLifecycle()
    var selectedFilter by remember { mutableStateOf<TerminalLogLevel?>(null) }

    val filteredLogs = remember(logs, selectedFilter) {
        if (selectedFilter == null) logs else logs.filter { it.level == selectedFilter }
    }

    val wsStatus = when (val fs = dashboardState.feedState) {
        is MarketFeedState.LiveWebSocket -> "OPEN (${fs.sourceName})"
        is MarketFeedState.LiveRestFallback -> "REST FALLBACK (${fs.note})"
        is MarketFeedState.Connecting -> "HANDSHAKE (${fs.sourceName})"
        is MarketFeedState.Reconnecting -> "RECONNECTING #${fs.attempt}"
        is MarketFeedState.UnsupportedSource -> "UNSUPPORTED SOURCE"
        is MarketFeedState.Error -> "ERROR: ${fs.message}"
        MarketFeedState.Idle -> "IDLE"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header & Clear Action
        CyberCard(isHighlighted = true, contentPadding = 12.dp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = CyberColors.NeonGreen, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.terminalTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        color = CyberColors.NeonGreen
                    )
                }
                IconButton(
                    onClick = { TerminalLogger.clear() },
                    modifier = Modifier.testTag("clear_terminal_logs_button")
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear logs", tint = CyberColors.TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            DiagnosticLine("MARKET FEED", "${dashboardState.activeAsset.symbol} (${dashboardState.activeTimeframe.code})", CyberColors.TextPrimary)
            DiagnosticLine("WEBSOCKET / API", wsStatus, if (dashboardState.feedState is MarketFeedState.LiveWebSocket) CyberColors.NeonGreen else CyberColors.CyberCyan)
            DiagnosticLine("GEMINI ENGINE", "${dashboardState.geminiStatus.label} (${dashboardState.settings.geminiModel})", if (dashboardState.geminiErrorNote != null) CyberColors.PutCrimson else CyberColors.NeonGreen)
            DiagnosticLine("LATENCY MONITOR", if (dashboardState.latencyMs > 0) "${dashboardState.latencyMs} ms" else "--", CyberColors.CyberCyan)
            DiagnosticLine("LAST UPDATE", Formatters.formatTime(dashboardState.lastUpdateMs), CyberColors.TextSecondary)
            DiagnosticLine("CANDLE BUFFER", "${dashboardState.candles.size} OHLC bars", CyberColors.TextSecondary)
        }

        // Log Level Filter Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChipBox("ALL", selectedFilter == null) { selectedFilter = null }
            TerminalLogLevel.entries.forEach { lvl ->
                FilterChipBox(lvl.code.trim(), selectedFilter == lvl) { selectedFilter = lvl }
            }
        }

        // Live Scrolling Terminal Log Output
        CyberCard(
            modifier = Modifier.weight(1f),
            contentPadding = 10.dp
        ) {
            if (filteredLogs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No truthful system events recorded for this filter yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberColors.TextMuted
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredLogs, key = { it.id }) { entry ->
                        val lvlColor = when (entry.level) {
                            TerminalLogLevel.ERR -> CyberColors.PutCrimson
                            TerminalLogLevel.WARN -> CyberColors.WarningAmber
                            TerminalLogLevel.WS -> CyberColors.NeonGreen
                            TerminalLogLevel.NET -> CyberColors.CyberCyan
                            TerminalLogLevel.AI -> Color(0xFF9E8CFF)
                            TerminalLogLevel.INFO -> CyberColors.TextSecondary
                        }
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = Formatters.formatTime(entry.timestampMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberColors.TextMuted
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "[${entry.level.code.trim()}]",
                                style = MaterialTheme.typography.labelSmall,
                                color = lvlColor,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${entry.tag}: ${entry.message}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberColors.TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticLine(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = valueColor,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun FilterChipBox(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) CyberColors.NeonGreen else CyberColors.TerminalSurface)
            .border(1.dp, if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) CyberColors.ObsidianBg else CyberColors.TextSecondary,
            fontWeight = FontWeight.Bold
        )
    }
}
