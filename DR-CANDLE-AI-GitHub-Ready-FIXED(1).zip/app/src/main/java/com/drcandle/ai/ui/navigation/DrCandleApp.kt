package com.drcandle.ai.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.CandlestickChart
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.drcandle.ai.ui.AppStrings
import com.drcandle.ai.ui.dashboard.DashboardScreen
import com.drcandle.ai.ui.dashboard.DashboardViewModel
import com.drcandle.ai.ui.history.HistoryScreen
import com.drcandle.ai.ui.history.HistoryViewModel
import com.drcandle.ai.ui.settings.SettingsScreen
import com.drcandle.ai.ui.settings.SettingsViewModel
import com.drcandle.ai.ui.terminal.TerminalScreen
import com.drcandle.ai.ui.theme.CyberColors
import com.drcandle.ai.ui.theme.DrCandleTheme

sealed class NavDestination(
    val route: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Dashboard : NavDestination("dashboard", Icons.Filled.CandlestickChart, Icons.Outlined.CandlestickChart)
    data object Terminal : NavDestination("terminal", Icons.Filled.Terminal, Icons.Outlined.Terminal)
    data object History : NavDestination("history", Icons.Filled.History, Icons.Outlined.History)
    data object Settings : NavDestination("settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun DrCandleApp(
    dashboardViewModel: DashboardViewModel = viewModel(),
    historyViewModel: HistoryViewModel = viewModel(),
    settingsViewModel: SettingsViewModel = viewModel()
) {
    val dashboardState by dashboardViewModel.uiState.collectAsStateWithLifecycle()
    val historyState by historyViewModel.uiState.collectAsStateWithLifecycle()
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val diagnostics by settingsViewModel.diagnostics.collectAsStateWithLifecycle()

    val strings = AppStrings.of(settings.language)
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val destinations = listOf(
        NavDestination.Dashboard to strings.navDashboard,
        NavDestination.Terminal to strings.navTerminal,
        NavDestination.History to strings.navHistory,
        NavDestination.Settings to strings.navSettings
    )

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    DrCandleTheme(pureBlackAmoled = settings.pureBlackAmoled) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = CyberColors.ObsidianBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = CyberColors.TerminalSurface,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            destinations.forEach { (dest, label) ->
                                val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    modifier = Modifier.testTag("nav_${dest.route}"),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = label,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CyberColors.ObsidianBg,
                                        selectedTextColor = CyberColors.NeonGreen,
                                        indicatorColor = CyberColors.NeonGreen,
                                        unselectedIconColor = CyberColors.TextSecondary,
                                        unselectedTextColor = CyberColors.TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(containerColor = CyberColors.TerminalSurface) {
                            destinations.forEach { (dest, label) ->
                                val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = { Text(label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = CyberColors.ObsidianBg,
                                        selectedTextColor = CyberColors.NeonGreen,
                                        indicatorColor = CyberColors.NeonGreen,
                                        unselectedIconColor = CyberColors.TextSecondary,
                                        unselectedTextColor = CyberColors.TextSecondary
                                    )
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = NavDestination.Dashboard.route,
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 720.dp)
                        ) {
                            composable(NavDestination.Dashboard.route) {
                                DashboardScreen(
                                    uiState = dashboardState,
                                    strings = strings,
                                    onSelectAsset = dashboardViewModel::selectAsset,
                                    onSelectTimeframe = dashboardViewModel::selectTimeframe,
                                    onRunScan = dashboardViewModel::runDualAiAnalysis
                                )
                            }
                            composable(NavDestination.Terminal.route) {
                                TerminalScreen(
                                    dashboardState = dashboardState,
                                    strings = strings
                                )
                            }
                            composable(NavDestination.History.route) {
                                HistoryScreen(
                                    uiState = historyState,
                                    strings = strings,
                                    onSelectFilter = historyViewModel::setFilter,
                                    onVerifyOutcome = historyViewModel::verifyOutcome,
                                    onDeleteEntry = historyViewModel::deleteEntry,
                                    onClearAll = historyViewModel::clearAll
                                )
                            }
                            composable(NavDestination.Settings.route) {
                                SettingsScreen(
                                    settings = settings,
                                    diagnostics = diagnostics,
                                    strings = strings,
                                    viewModel = settingsViewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
