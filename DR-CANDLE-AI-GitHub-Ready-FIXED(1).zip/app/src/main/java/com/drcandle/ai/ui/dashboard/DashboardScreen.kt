package com.drcandle.ai.ui.dashboard

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.domain.VolatilityLevel
import com.drcandle.ai.services.FloatingScannerService
import com.drcandle.ai.ui.AppStrings
import com.drcandle.ai.ui.theme.AnimatedCyberLogo
import com.drcandle.ai.ui.theme.CandlestickChartCanvas
import com.drcandle.ai.ui.theme.CyberCard
import com.drcandle.ai.ui.theme.CyberColors
import com.drcandle.ai.ui.theme.ScanningBeamBar
import com.drcandle.ai.ui.theme.StatusLedPill
import com.drcandle.ai.utils.Formatters
import com.example.R

@Composable
fun DashboardScreen(
    uiState: DashboardUiState,
    strings: AppStrings,
    onSelectAsset: (String) -> Unit,
    onSelectTimeframe: (String) -> Unit,
    onRunScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val latestCandle = uiState.candles.lastOrNull()
    val decimals = uiState.activeAsset.priceDecimals

    val (feedLabel, feedColor, isFeedPulsing) = when (val fs = uiState.feedState) {
        is MarketFeedState.LiveWebSocket -> Triple("LIVE WS", CyberColors.NeonGreen, true)
        is MarketFeedState.LiveRestFallback -> Triple("LIVE REST", CyberColors.CyberCyan, true)
        is MarketFeedState.Connecting -> Triple("CONNECTING", CyberColors.WarningAmber, true)
        is MarketFeedState.Reconnecting -> Triple("RETRY #${fs.attempt}", CyberColors.WarningAmber, true)
        is MarketFeedState.UnsupportedSource -> Triple("UNSUPPORTED", CyberColors.WarningAmber, false)
        is MarketFeedState.Error -> Triple("FEED ERROR", CyberColors.PutCrimson, false)
        MarketFeedState.Idle -> Triple("STANDBY", CyberColors.TextMuted, false)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. DR CANDLE TRACKER Header with Animated Logo + Banner Art
        item {
            CyberCard(isHighlighted = true, contentPadding = 0.dp) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_terminal_banner_1795278474283),
                        contentDescription = "DR CANDLE AI Terminal Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .matchParentSize()
                            .alpha(0.22f)
                    )
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                AnimatedCyberLogo()
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = strings.trackerTitle,
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = CyberColors.NeonGreen,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = strings.trackerSubtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberColors.TextSecondary,
                                        maxLines = 1
                                    )
                                }
                            }
                            StatusLedPill(
                                label = feedLabel,
                                color = feedColor,
                                isPulsing = isFeedPulsing
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        ScanningBeamBar(isActive = uiState.isAnalyzing || uiState.scannerState.isScanning)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Live Asset + Timeframe + Latency Quick Strip
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = uiState.activeAsset.symbol,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberColors.TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${uiState.activeAsset.displayName} • ${uiState.activeTimeframe.code}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberColors.TextSecondary
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = strings.latencyLabel,
                                    tint = CyberColors.CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (uiState.latencyMs > 0) "${uiState.latencyMs}ms" else "-- ms",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = CyberColors.CyberCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Honest Limitation / Error Diagnostic Banner (e.g. Quotex OTC or API key needed)
        if (uiState.feedState is MarketFeedState.UnsupportedSource || uiState.feedState is MarketFeedState.Error) {
            item {
                val message = when (val fs = uiState.feedState) {
                    is MarketFeedState.UnsupportedSource -> fs.limitationMessage
                    is MarketFeedState.Error -> "${fs.sourceName}: ${fs.message}"
                    else -> ""
                }
                CyberCard(glowColor = CyberColors.WarningAmber, isHighlighted = true) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = "Feed limitation",
                            tint = CyberColors.WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DATA SOURCE NOTICE (NO SIMULATED PRICES)",
                                style = MaterialTheme.typography.labelMedium,
                                color = CyberColors.WarningAmber,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberColors.TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // 2. Asset & Timeframe Selector Strip
        item {
            CyberCard(contentPadding = 10.dp) {
                Text(
                    text = "ASSET STREAM",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberColors.TextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SupportedAssets.all.forEach { asset ->
                        val selected = asset.symbol == uiState.activeAsset.symbol
                        val chipColor = if (asset.isOtc) CyberColors.WarningAmber else CyberColors.NeonGreen
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (selected) chipColor.copy(alpha = 0.2f) else CyberColors.ObsidianBg
                                )
                                .border(
                                    1.dp,
                                    if (selected) chipColor else CyberColors.BorderSubtle,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectAsset(asset.symbol) }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("asset_chip_${asset.symbol}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = asset.symbol,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) chipColor else CyberColors.TextSecondary,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.timeframeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberColors.TextMuted
                    )
                    Timeframe.entries.forEach { tf ->
                        val selected = tf == uiState.activeTimeframe
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (selected) CyberColors.NeonGreen else CyberColors.ObsidianBg
                                )
                                .border(
                                    1.dp,
                                    if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectTimeframe(tf.code) }
                                .padding(vertical = 8.dp)
                                .testTag("tf_chip_${tf.code}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tf.code.uppercase(),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) CyberColors.ObsidianBg else CyberColors.TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 3. Live Candlestick Chart + 4. OHLC Strip
        item {
            CyberCard(contentPadding = 12.dp) {
                CandlestickChartCanvas(
                    candles = uiState.candles,
                    indicators = uiState.liveIndicators,
                    priceDecimals = decimals,
                    isScanning = uiState.isAnalyzing
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OhlcCell("OPEN", latestCandle?.open?.let { Formatters.formatPrice(it, decimals) } ?: "--", Modifier.weight(1f))
                    OhlcCell("HIGH", latestCandle?.high?.let { Formatters.formatPrice(it, decimals) } ?: "--", Modifier.weight(1f), CyberColors.NeonGreen)
                    OhlcCell("LOW", latestCandle?.low?.let { Formatters.formatPrice(it, decimals) } ?: "--", Modifier.weight(1f), CyberColors.PutCrimson)
                    OhlcCell("CLOSE", latestCandle?.close?.let { Formatters.formatPrice(it, decimals) } ?: "--", Modifier.weight(1f), CyberColors.CyberCyan)
                }
            }
        }

        // 5. Telemetry Grid: Volatility, AI Confidence Meter, Gemini Status, Local Status
        item {
            val vol = uiState.liveIndicators?.volatilityLevel ?: VolatilityLevel.MODERATE
            val volPct = uiState.liveIndicators?.volatilityPercent ?: 0.0
            val signalConf = uiState.latestSignal?.confidencePercent ?: 0

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CyberCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = CyberColors.WarningAmber, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.volatilityLabel, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${vol.label} (${Formatters.formatPercent(volPct)})",
                            style = MaterialTheme.typography.titleSmall,
                            color = when (vol) {
                                VolatilityLevel.LOW -> CyberColors.CyberCyan
                                VolatilityLevel.MODERATE -> CyberColors.NeonGreen
                                VolatilityLevel.HIGH -> CyberColors.WarningAmber
                                VolatilityLevel.EXTREME -> CyberColors.PutCrimson
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }

                    CyberCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = CyberColors.CyberCyan, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.latencyLabel, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (uiState.latencyMs > 0) "${uiState.latencyMs} ms • ${uiState.candles.size}c" else "NO FEED",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberColors.TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Engine statuses: Gemini AI & Local AI
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    EngineStatusCard(
                        title = strings.geminiAiLabel,
                        subtitle = uiState.settings.geminiModel,
                        status = uiState.geminiStatus,
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberColors.CyberCyan, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                    EngineStatusCard(
                        title = strings.localAiLabel,
                        subtitle = "EMA•RSI•MACD•BB",
                        status = uiState.localStatus,
                        icon = { Icon(Icons.Default.Memory, contentDescription = null, tint = CyberColors.NeonGreen, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // AI Confidence Meter + Analysis Progress
                CyberCard(contentPadding = 12.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.confidenceMeter, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextSecondary)
                        Text(
                            text = "$signalConf%",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberColors.NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (signalConf / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = when {
                            signalConf >= 70 -> CyberColors.NeonGreen
                            signalConf >= 50 -> CyberColors.CyberCyan
                            else -> CyberColors.WarningAmber
                        },
                        trackColor = CyberColors.GridLine
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = strings.confidenceDisclaimer,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberColors.TextMuted
                    )

                    AnimatedVisibility(visible = uiState.isAnalyzing) {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(
                                text = strings.scanningInProgress,
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberColors.NeonGreen
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp),
                                color = CyberColors.NeonGreen,
                                trackColor = CyberColors.GridLine
                            )
                        }
                    }
                }
            }
        }

        // 6. Action Buttons: Dual AI Scan + Floating Scanner Launch
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onRunScan,
                    enabled = !uiState.isAnalyzing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("run_dual_ai_scan_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberColors.NeonGreen,
                        contentColor = CyberColors.ObsidianBg,
                        disabledContainerColor = CyberColors.NeonGreen.copy(alpha = 0.35f)
                    )
                ) {
                    Icon(Icons.Default.Radar, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (uiState.isAnalyzing) strings.scanningInProgress else strings.runDualAiScan,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                val isScannerActive = uiState.scannerState.isServiceRunning
                OutlinedButton(
                    onClick = {
                        if (!Settings.canDrawOverlays(context)) {
                            val permIntent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(permIntent)
                        } else {
                            val svcIntent = Intent(context, FloatingScannerService::class.java).apply {
                                action = if (isScannerActive) {
                                    FloatingScannerService.ACTION_STOP_OVERLAY
                                } else {
                                    FloatingScannerService.ACTION_START_OVERLAY
                                }
                            }
                            if (!isScannerActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(svcIntent)
                            } else {
                                context.startService(svcIntent)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("toggle_floating_scanner_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isScannerActive) CyberColors.PutCrimson else CyberColors.CyberCyan
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusStrong,
                        contentDescription = null,
                        tint = if (isScannerActive) CyberColors.PutCrimson else CyberColors.CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isScannerActive) strings.stopFloatingScanner else strings.launchFloatingScanner,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isScannerActive) CyberColors.PutCrimson else CyberColors.CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 7. Latest Trading Signal Output Panel
        item {
            SignalOutputPanel(
                signal = uiState.latestSignal,
                indicators = uiState.liveIndicators,
                priceDecimals = decimals,
                strings = strings
            )
        }
    }
}

@Composable
private fun OhlcCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = CyberColors.TextPrimary
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CyberColors.ObsidianBg)
            .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun EngineStatusCard(
    title: String,
    subtitle: String,
    status: EngineStatus,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor = when (status) {
        EngineStatus.READY -> CyberColors.NeonGreen
        EngineStatus.RUNNING -> CyberColors.CyberCyan
        EngineStatus.FAILED -> CyberColors.PutCrimson
        EngineStatus.DEGRADED -> CyberColors.WarningAmber
        EngineStatus.IDLE -> CyberColors.TextMuted
    }
    CyberCard(modifier = modifier, glowColor = statusColor, contentPadding = 11.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon()
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextSecondary)
            }
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                color = statusColor,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = CyberColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SignalOutputPanel(
    signal: com.drcandle.ai.domain.CombinedSignal?,
    indicators: com.drcandle.ai.domain.TechnicalIndicators?,
    priceDecimals: Int,
    strings: AppStrings
) {
    val direction = signal?.direction ?: SignalDirection.NO_SIGNAL
    val signalColor = when (direction) {
        SignalDirection.CALL -> CyberColors.NeonGreen
        SignalDirection.PUT -> CyberColors.PutCrimson
        SignalDirection.NO_SIGNAL -> CyberColors.WarningAmber
    }

    CyberCard(glowColor = signalColor, isHighlighted = signal != null) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.signalPanelTitle,
                style = MaterialTheme.typography.labelMedium,
                color = CyberColors.TextSecondary,
                fontWeight = FontWeight.Bold
            )
            if (signal != null) {
                Text(
                    text = Formatters.formatTime(signal.timestampMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberColors.TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (signal == null) {
            Text(
                text = "Tap ${strings.runDualAiScan} to analyze live market candles concurrently with Local Technical Engine + Gemini AI.",
                style = MaterialTheme.typography.bodyMedium,
                color = CyberColors.TextSecondary
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(signalColor.copy(alpha = 0.14f))
                    .border(1.dp, signalColor, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (direction) {
                            SignalDirection.CALL -> Icons.AutoMirrored.Filled.TrendingUp
                            SignalDirection.PUT -> Icons.AutoMirrored.Filled.TrendingDown
                            SignalDirection.NO_SIGNAL -> Icons.Default.PauseCircle
                        },
                        contentDescription = direction.label,
                        tint = signalColor,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = direction.label,
                            style = MaterialTheme.typography.displaySmall,
                            color = signalColor
                        )
                        Text(
                            text = "${signal.assetSymbol} • ${signal.timeframeCode}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberColors.TextPrimary
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${signal.confidencePercent}%",
                        style = MaterialTheme.typography.headlineSmall,
                        color = signalColor
                    )
                    Text(
                        text = "ALIGNMENT",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberColors.TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OhlcCell(
                    strings.entryPriceLabel,
                    Formatters.formatPrice(signal.entryPrice, priceDecimals),
                    Modifier.weight(1f),
                    CyberColors.TextPrimary
                )
                OhlcCell(
                    strings.expiryLabel,
                    "${signal.suggestedExpiryMinutes}m",
                    Modifier.weight(1f),
                    CyberColors.CyberCyan
                )
                OhlcCell(
                    strings.trendLabel,
                    signal.trendDirection.label,
                    Modifier.weight(1f),
                    CyberColors.NeonGreen
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "TECHNICAL REASONING",
                style = MaterialTheme.typography.labelSmall,
                color = CyberColors.TextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = signal.reasoning,
                style = MaterialTheme.typography.bodyMedium,
                color = CyberColors.TextPrimary
            )

            if (signal.geminiResult.status == EngineStatus.FAILED) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "GEMINI DIAGNOSTIC: ${signal.geminiResult.errorMessage}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberColors.PutCrimson
                )
            }
        }

        if (indicators != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = strings.indicatorsLabel,
                style = MaterialTheme.typography.labelSmall,
                color = CyberColors.TextMuted
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OhlcCell("EMA 9", Formatters.formatPrice(indicators.ema9, priceDecimals), Modifier.weight(1f), CyberColors.CyberCyan)
                OhlcCell("EMA 21", Formatters.formatPrice(indicators.ema21, priceDecimals), Modifier.weight(1f), CyberColors.WarningAmber)
                OhlcCell("RSI 14", Formatters.formatPrice(indicators.rsi14, 1), Modifier.weight(1f), CyberColors.NeonGreen)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OhlcCell("MACD", Formatters.formatPrice(indicators.macdHistogram, priceDecimals + 2), Modifier.weight(1f))
                OhlcCell("BB UP", Formatters.formatPrice(indicators.bbUpper, priceDecimals), Modifier.weight(1f))
                OhlcCell("BB LOW", Formatters.formatPrice(indicators.bbLower, priceDecimals), Modifier.weight(1f))
            }

            if (indicators.detectedPatterns.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${strings.patternsLabel}: ${indicators.detectedPatterns.joinToString { it.label }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberColors.NeonGreen
                )
            }
        }
    }
}
