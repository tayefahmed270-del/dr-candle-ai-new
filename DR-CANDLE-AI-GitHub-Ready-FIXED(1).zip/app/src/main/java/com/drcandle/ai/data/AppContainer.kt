package com.drcandle.ai.data

import android.content.Context
import com.drcandle.ai.ai.CombinedAnalysisEngine
import com.drcandle.ai.ai.GeminiAnalysisEngine
import com.drcandle.ai.ai.LocalAnalysisEngine
import com.drcandle.ai.database.DrCandleDatabase
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.market.MarketRepository
import com.drcandle.ai.scanner.LocalBitmapChartAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ScannerOverlayState(
    val isServiceRunning: Boolean = false,
    val isScanning: Boolean = false,
    val statusText: String = "Standby",
    val lastDirection: SignalDirection = SignalDirection.NO_SIGNAL,
    val lastConfidence: Int = 0,
    val lastReasoning: String = "",
    val lastError: String? = null,
    val lastScanTimestampMs: Long = 0L
)

class AppContainer private constructor(context: Context) {
    private val appContext = context.applicationContext

    val database: DrCandleDatabase by lazy { DrCandleDatabase.getInstance(appContext) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(appContext) }
    val historyRepository: HistoryRepository by lazy { HistoryRepository(database.signalHistoryDao()) }
    val marketRepository: MarketRepository by lazy { MarketRepository() }

    val localAnalysisEngine: LocalAnalysisEngine by lazy { LocalAnalysisEngine() }
    val geminiAnalysisEngine: GeminiAnalysisEngine by lazy { GeminiAnalysisEngine() }
    val combinedAnalysisEngine: CombinedAnalysisEngine by lazy {
        CombinedAnalysisEngine(localAnalysisEngine, geminiAnalysisEngine)
    }
    val localBitmapChartAnalyzer: LocalBitmapChartAnalyzer by lazy { LocalBitmapChartAnalyzer() }

    private val _scannerState = MutableStateFlow(ScannerOverlayState())
    val scannerState: StateFlow<ScannerOverlayState> = _scannerState.asStateFlow()

    fun updateScannerState(transform: (ScannerOverlayState) -> ScannerOverlayState) {
        _scannerState.value = transform(_scannerState.value)
    }

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun getInstance(context: Context): AppContainer {
            return instance ?: synchronized(this) {
                instance ?: AppContainer(context).also { instance = it }
            }
        }
    }
}
