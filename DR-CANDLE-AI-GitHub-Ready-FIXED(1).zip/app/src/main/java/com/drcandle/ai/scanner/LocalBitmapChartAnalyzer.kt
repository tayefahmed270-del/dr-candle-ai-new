package com.drcandle.ai.scanner

import android.graphics.Bitmap
import android.graphics.Color
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.LocalAnalysisResult
import com.drcandle.ai.domain.SignalDirection
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Local fallback analyzer for captured chart screenshots when Gemini Vision fails or is offline.
 * Measures actual green (bullish) vs red (bearish) candlestick pixel columns and recent right-edge momentum.
 */
class LocalBitmapChartAnalyzer {

    fun analyzeScreenshot(bitmap: Bitmap): LocalAnalysisResult {
        val startMs = System.currentTimeMillis()
        return try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 40 || h < 40) {
                return LocalAnalysisResult(
                    direction = SignalDirection.NO_SIGNAL,
                    confidencePercent = 0,
                    indicators = null,
                    reasoning = "Captured bitmap too small (${w}x${h}) for chart analysis.",
                    durationMs = 1L,
                    status = EngineStatus.FAILED,
                    errorMessage = "Bitmap too small"
                )
            }

            // Sample middle 60% vertical band across horizontal chart region (15%..90%)
            val xStart = (w * 0.15).toInt()
            val xEnd = (w * 0.90).toInt()
            val yStart = (h * 0.20).toInt()
            val yEnd = (h * 0.80).toInt()

            var greenPixels = 0
            var redPixels = 0
            var rightEdgeGreen = 0
            var rightEdgeRed = 0
            var weightedGreenY = 0.0
            var weightedRedY = 0.0

            val rightEdgeStart = (w * 0.68).toInt()
            val step = 3

            for (x in xStart until xEnd step step) {
                for (y in yStart until yEnd step step) {
                    val pixel = bitmap.getPixel(x, y)
                    val r = Color.red(pixel)
                    val g = Color.green(pixel)
                    val b = Color.blue(pixel)

                    val isBullishGreen = g > 110 && g > r + 35 && g > b + 20
                    val isBearishRed = r > 120 && r > g + 35 && r > b + 20

                    if (isBullishGreen) {
                        greenPixels++
                        weightedGreenY += y
                        if (x >= rightEdgeStart) rightEdgeGreen++
                    } else if (isBearishRed) {
                        redPixels++
                        weightedRedY += y
                        if (x >= rightEdgeStart) rightEdgeRed++
                    }
                }
            }

            val totalCandlePixels = greenPixels + redPixels
            if (totalCandlePixels < 25) {
                return LocalAnalysisResult(
                    direction = SignalDirection.NO_SIGNAL,
                    confidencePercent = 0,
                    indicators = null,
                    reasoning = "No clear candlestick chart colors detected in screen capture ($totalCandlePixels candle pixels).",
                    durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                    status = EngineStatus.READY
                )
            }

            val greenRatio = greenPixels.toDouble() / totalCandlePixels
            val rightTotal = (rightEdgeGreen + rightEdgeRed).coerceAtLeast(1)
            val rightGreenRatio = rightEdgeGreen.toDouble() / rightTotal

            val compositeBias = (greenRatio * 0.35 + rightGreenRatio * 0.65) - 0.5
            val absBias = abs(compositeBias)

            val direction = when {
                compositeBias > 0.12 -> SignalDirection.CALL
                compositeBias < -0.12 -> SignalDirection.PUT
                else -> SignalDirection.NO_SIGNAL
            }
            val confidence = when (direction) {
                SignalDirection.NO_SIGNAL -> 38
                else -> (52 + absBias * 75).roundToInt().coerceIn(52, 78)
            }

            val reasoning = "Local pixel fallback scanned $totalCandlePixels candle pixels " +
                "(Overall Green=${(greenRatio * 100).roundToInt()}%, Right-edge Green=${(rightGreenRatio * 100).roundToInt()}%)."

            LocalAnalysisResult(
                direction = direction,
                confidencePercent = confidence,
                indicators = null,
                reasoning = reasoning,
                durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                status = EngineStatus.READY
            )
        } catch (e: Exception) {
            LocalAnalysisResult(
                direction = SignalDirection.NO_SIGNAL,
                confidencePercent = 0,
                indicators = null,
                reasoning = "Local bitmap analysis failed: ${e.localizedMessage}",
                durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                status = EngineStatus.FAILED,
                errorMessage = e.localizedMessage
            )
        }
    }
}
