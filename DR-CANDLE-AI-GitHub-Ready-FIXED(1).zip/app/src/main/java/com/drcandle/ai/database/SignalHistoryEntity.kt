package com.drcandle.ai.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signal_history")
data class SignalHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestampMs: Long,
    val assetSymbol: String,
    val direction: String, // CALL, PUT, NO_SIGNAL
    val confidencePercent: Int,
    val entryPrice: Double,
    val priceDecimals: Int,
    val timeframeCode: String,
    val suggestedExpiryMinutes: Int,
    val trendDirection: String,
    val detailedAnalysis: String,
    val localSummary: String,
    val geminiSummary: String,
    val outcome: String = "PENDING", // PENDING, WIN, LOSS, SKIPPED
    val verifiedAtMs: Long? = null,
    val isFromScreenScanner: Boolean = false
)
