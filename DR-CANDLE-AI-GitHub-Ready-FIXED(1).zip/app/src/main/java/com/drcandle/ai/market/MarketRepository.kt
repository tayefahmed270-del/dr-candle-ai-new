package com.drcandle.ai.market

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class MarketRepository(
    private val providers: List<MarketDataProvider> = listOf(
        CustomOtcFeedProvider(),
        BinanceMarketDataProvider(),
        TwelveDataMarketDataProvider()
    )
) {
    fun resolveProvider(asset: MarketAsset, settings: AppSettings): MarketDataProvider? =
        providers.firstOrNull { it.supports(asset, settings) }

    fun streamAsset(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Flow<MarketStreamEvent> {
        val provider = resolveProvider(asset, settings)
        if (provider == null) {
            val msg = "No genuine market data provider supports ${asset.symbol}."
            TerminalLogger.warn("MARKET", msg)
            return flowOf(MarketStreamEvent.StateChanged(MarketFeedState.UnsupportedSource("Provider Router", msg)))
        }
        TerminalLogger.info("MARKET", "Routing ${asset.symbol} (${timeframe.code}) -> ${provider.displayName}")
        return provider.streamMarketData(asset, timeframe, settings)
    }

    suspend fun testProviderConnectivity(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Result<Pair<List<Candle>, Long>> {
        val provider = resolveProvider(asset, settings)
            ?: return Result.failure(IllegalStateException("No provider available for ${asset.symbol}"))
        return provider.fetchHistoricalCandles(asset, timeframe, 40, settings)
    }
}
