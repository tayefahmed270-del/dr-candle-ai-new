package com.drcandle.ai.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drcandle.ai.data.AppContainer
import com.drcandle.ai.database.SignalHistoryEntity
import com.drcandle.ai.domain.SignalOutcome
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HistoryFilter(val label: String) {
    ALL("ALL"),
    CALL("CALL"),
    PUT("PUT"),
    NO_SIGNAL("NO SIGNAL")
}

data class HistoryUiState(
    val entries: List<SignalHistoryEntity> = emptyList(),
    val selectedFilter: HistoryFilter = HistoryFilter.ALL,
    val totalCount: Int = 0,
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val pendingCount: Int = 0
)

class HistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val historyRepo = AppContainer.getInstance(application).historyRepository
    private val filterFlow = MutableStateFlow(HistoryFilter.ALL)

    val uiState: StateFlow<HistoryUiState> = combine(
        historyRepo.allHistory,
        filterFlow
    ) { all, filter ->
        val filtered = when (filter) {
            HistoryFilter.ALL -> all
            HistoryFilter.CALL -> all.filter { it.direction == "CALL" }
            HistoryFilter.PUT -> all.filter { it.direction == "PUT" }
            HistoryFilter.NO_SIGNAL -> all.filter { it.direction == "NO_SIGNAL" }
        }
        HistoryUiState(
            entries = filtered,
            selectedFilter = filter,
            totalCount = all.size,
            winCount = all.count { it.outcome == SignalOutcome.WIN.name },
            lossCount = all.count { it.outcome == SignalOutcome.LOSS.name },
            pendingCount = all.count { it.outcome == SignalOutcome.PENDING.name }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = HistoryUiState()
    )

    fun setFilter(filter: HistoryFilter) {
        filterFlow.value = filter
    }

    fun verifyOutcome(id: Long, outcome: SignalOutcome) {
        viewModelScope.launch {
            historyRepo.verifyOutcome(id, outcome)
        }
    }

    fun deleteEntry(id: Long) {
        viewModelScope.launch {
            historyRepo.deleteEntry(id)
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            historyRepo.clearAll()
        }
    }
}
