package com.drcandle.ai.market

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.network.NetworkModule
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

class BinanceMarketDataProvider : MarketDataProvider {
    override val providerId: String = "binance_spot"
    override val displayName: String = "Binance Spot WebSocket + REST"
    override val supportsWebSocket: Boolean = true

    override fun supports(asset: MarketAsset, settings: AppSettings): Boolean =
        !asset.isOtc && asset.binanceSymbol != null

    override suspend fun fetchHistoricalCandles(
        asset: MarketAsset,
        timeframe: Timeframe,
        limit: Int,
        settings: AppSettings
    ): Result<Pair<List<Candle>, Long>> = withContext(Dispatchers.IO) {
        val symbol = asset.binanceSymbol
            ?: return@withContext Result.failure(IllegalArgumentException("No Binance symbol for ${asset.symbol}"))

        val startMs = System.currentTimeMillis()
        try {
            val primaryResponse = runCatching {
                NetworkModule.binancePrimaryApi.getKlines(
                    symbol = symbol,
                    interval = timeframe.binanceInterval,
                    limit = limit.coerceIn(30, 500)
                )
            }.getOrNull()

            val response = if (primaryResponse != null && primaryResponse.isSuccessful) {
                primaryResponse
            } else {
                TerminalLogger.warn("BINANCE", "Primary REST returned ${primaryResponse?.code() ?: "network error"}, trying data-api.binance.vision mirror.")
                NetworkModule.binanceVisionApi.getKlines(
                    symbol = symbol,
                    interval = timeframe.binanceInterval,
                    limit = limit.coerceIn(30, 500)
                )
            }

            val latency = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            if (!response.isSuccessful) {
                val err = "HTTP ${response.code()} ${response.message()}"
                TerminalLogger.err("BINANCE", "Historical kline fetch failed: $err")
                return@withContext Result.failure(IllegalStateException(err))
            }

            val rawList = response.body().orEmpty()
            val candles = rawList.mapNotNull { row -> parseKlineRow(row) }
            if (candles.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("Empty kline payload from Binance"))
            }

            TerminalLogger.net("BINANCE", "Loaded ${candles.size} historical ${timeframe.code} candles for $symbol (${latency}ms)")
            Result.success(candles to latency)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            TerminalLogger.err("BINANCE", "REST historical fetch error: ${e.localizedMessage}")
            Result.failure(e)
        }
    }

    override fun streamMarketData(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Flow<MarketStreamEvent> = callbackFlow {
        val symbol = asset.binanceSymbol
        if (symbol == null) {
            trySend(
                MarketStreamEvent.StateChanged(
                    MarketFeedState.UnsupportedSource(displayName, "Asset ${asset.symbol} is not mapped to Binance.")
                )
            )
            close()
            return@callbackFlow
        }

        trySend(MarketStreamEvent.StateChanged(MarketFeedState.Connecting(displayName)))

        // Step 1: Load initial historical candles via REST
        val histResult = fetchHistoricalCandles(asset, timeframe, 120, settings)
        histResult.onSuccess { (candles, latency) ->
            trySend(MarketStreamEvent.HistoricalSnapshot(candles, latency))
        }.onFailure { err ->
            trySend(MarketStreamEvent.StateChanged(MarketFeedState.Error(displayName, err.localizedMessage ?: "Historical fetch failed")))
        }

        // Step 2: Open live WebSocket stream with automatic reconnection & REST fallback
        var activeWebSocket: WebSocket? = null
        var closedByCollector = false
        var useVisionMirror = false
        var reconnectAttempt = 0

        val supervisorJob = launch(Dispatchers.IO) {
            while (isActive && !closedByCollector) {
                val baseWs = if (useVisionMirror) {
                    "wss://data-stream.binance.vision/ws"
                } else {
                    "wss://stream.binance.com:9443/ws"
                }
                val streamUrl = "$baseWs/${symbol.lowercase()}@kline_${timeframe.binanceInterval}"
                TerminalLogger.ws("BINANCE_WS", "Dialing $streamUrl (attempt ${reconnectAttempt + 1})")

                var socketFailureSignal = false
                val lock = Object()

                val request = Request.Builder().url(streamUrl).build()
                val ws = NetworkModule.okHttpClient.newWebSocket(
                    request,
                    object : WebSocketListener() {
                        override fun onOpen(webSocket: WebSocket, response: Response) {
                            reconnectAttempt = 0
                            TerminalLogger.ws("BINANCE_WS", "WebSocket OPEN for $symbol@${timeframe.binanceInterval}")
                            trySend(
                                MarketStreamEvent.StateChanged(
                                    MarketFeedState.LiveWebSocket(displayName, System.currentTimeMillis())
                                )
                            )
                        }

                        override fun onMessage(webSocket: WebSocket, text: String) {
                            try {
                                val json = JSONObject(text)
                                val eventTime = json.optLong("E", System.currentTimeMillis())
                                val k = json.optJSONObject("k") ?: return
                                val candle = Candle(
                                    openTimeMs = k.getLong("t"),
                                    open = k.getString("o").toDouble(),
                                    high = k.getString("h").toDouble(),
                                    low = k.getString("l").toDouble(),
                                    close = k.getString("c").toDouble(),
                                    volume = k.getString("v").toDouble(),
                                    isClosed = k.optBoolean("x", false)
                                )
                                val latency = (System.currentTimeMillis() - eventTime).coerceIn(1L, 10_000L)
                                trySend(MarketStreamEvent.CandleUpdate(candle, latency))
                                trySend(
                                    MarketStreamEvent.StateChanged(
                                        MarketFeedState.LiveWebSocket(displayName, System.currentTimeMillis())
                                    )
                                )
                            } catch (e: Exception) {
                                TerminalLogger.warn("BINANCE_WS", "Malformed tick frame: ${e.localizedMessage}")
                            }
                        }

                        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                            TerminalLogger.warn("BINANCE_WS", "WebSocket failure (${response?.code ?: "net"}): ${t.localizedMessage}")
                            synchronized(lock) {
                                socketFailureSignal = true
                                lock.notifyAll()
                            }
                        }

                        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                            TerminalLogger.ws("BINANCE_WS", "WebSocket closed [$code]: $reason")
                            synchronized(lock) {
                                socketFailureSignal = true
                                lock.notifyAll()
                            }
                        }
                    }
                )
                activeWebSocket = ws

                // Wait until failure or cancellation
                while (isActive && !closedByCollector && !socketFailureSignal) {
                    delay(500L)
                }

                ws.cancel()
                if (closedByCollector || !isActive) break

                // Fallback REST poll so dashboard stays live even during WebSocket reconnect
                reconnectAttempt++
                useVisionMirror = !useVisionMirror
                trySend(
                    MarketStreamEvent.StateChanged(
                        MarketFeedState.Reconnecting(
                            sourceName = displayName,
                            attempt = reconnectAttempt,
                            reason = "WebSocket disconnected, polling REST fallback"
                        )
                    )
                )
                fetchHistoricalCandles(asset, timeframe, 120, settings).onSuccess { (candles, latency) ->
                    trySend(MarketStreamEvent.HistoricalSnapshot(candles, latency))
                    trySend(
                        MarketStreamEvent.StateChanged(
                            MarketFeedState.LiveRestFallback(
                                sourceName = displayName,
                                note = "REST fallback active while reconnecting WS",
                                lastTickMs = System.currentTimeMillis()
                            )
                        )
                    )
                }

                val backoffMs = (2000L * reconnectAttempt).coerceAtMost(12_000L)
                delay(backoffMs)
            }
        }

        awaitClose {
            closedByCollector = true
            supervisorJob.cancel()
            activeWebSocket?.cancel()
            TerminalLogger.ws("BINANCE_WS", "Closed market stream for $symbol")
        }
    }

    private fun parseKlineRow(row: List<Any>): Candle? {
        return try {
            if (row.size < 6) return null
            val openTime = (row[0] as? Number)?.toLong() ?: row[0].toString().toDouble().toLong()
            val open = row[1].toString().toDouble()
            val high = row[2].toString().toDouble()
            val low = row[3].toString().toDouble()
            val close = row[4].toString().toDouble()
            val volume = row[5].toString().toDouble()
            Candle(
                openTimeMs = openTime,
                open = open,
                high = high,
                low = low,
                close = close,
                volume = volume,
                isClosed = true
            )
        } catch (_: Exception) {
            null
        }
    }
}
