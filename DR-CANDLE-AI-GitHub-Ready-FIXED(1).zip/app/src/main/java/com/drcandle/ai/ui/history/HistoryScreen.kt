package com.drcandle.ai.ui.history

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.drcandle.ai.database.SignalHistoryEntity
import com.drcandle.ai.domain.SignalOutcome
import com.drcandle.ai.ui.AppStrings
import com.drcandle.ai.ui.theme.CyberCard
import com.drcandle.ai.ui.theme.CyberColors
import com.drcandle.ai.utils.Formatters

@Composable
fun HistoryScreen(
    uiState: HistoryUiState,
    strings: AppStrings,
    onSelectFilter: (HistoryFilter) -> Unit,
    onVerifyOutcome: (Long, SignalOutcome) -> Unit,
    onDeleteEntry: (Long) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header + Stats Card
        CyberCard(isHighlighted = true, contentPadding = 12.dp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = CyberColors.NeonGreen, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.historyTitle, style = MaterialTheme.typography.headlineSmall, color = CyberColors.NeonGreen)
                }
                if (uiState.totalCount > 0) {
                    IconButton(
                        onClick = onClearAll,
                        modifier = Modifier.testTag("clear_history_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear history", tint = CyberColors.PutCrimson)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatPill("SCANS", uiState.totalCount.toString(), CyberColors.TextPrimary, Modifier.weight(1f))
                StatPill("WIN", uiState.winCount.toString(), CyberColors.NeonGreen, Modifier.weight(1f))
                StatPill("LOSS", uiState.lossCount.toString(), CyberColors.PutCrimson, Modifier.weight(1f))
                StatPill("OPEN", uiState.pendingCount.toString(), CyberColors.WarningAmber, Modifier.weight(1f))
            }
        }

        // Filter chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HistoryFilter.entries.forEach { filter ->
                val selected = filter == uiState.selectedFilter
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) CyberColors.NeonGreen else CyberColors.TerminalSurface)
                        .border(1.dp, if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onSelectFilter(filter) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = filter.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) CyberColors.ObsidianBg else CyberColors.TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (uiState.entries.isEmpty()) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = CyberColors.TextMuted,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = strings.historyEmpty,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberColors.TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(uiState.entries, key = { it.id }) { item ->
                    HistoryEntryCard(
                        item = item,
                        onVerifyOutcome = { outcome -> onVerifyOutcome(item.id, outcome) },
                        onDelete = { onDeleteEntry(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatPill(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CyberColors.ObsidianBg)
            .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
        Text(value, style = MaterialTheme.typography.titleMedium, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HistoryEntryCard(
    item: SignalHistoryEntity,
    onVerifyOutcome: (SignalOutcome) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val dirColor = when (item.direction) {
        "CALL" -> CyberColors.NeonGreen
        "PUT" -> CyberColors.PutCrimson
        else -> CyberColors.WarningAmber
    }
    val outcomeColor = when (item.outcome) {
        SignalOutcome.WIN.name -> CyberColors.NeonGreen
        SignalOutcome.LOSS.name -> CyberColors.PutCrimson
        SignalOutcome.SKIPPED.name -> CyberColors.TextMuted
        else -> CyberColors.CyberCyan
    }

    CyberCard(glowColor = dirColor, contentPadding = 12.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = item.direction.replace("_", " "),
                        style = MaterialTheme.typography.titleMedium,
                        color = dirColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${item.confidencePercent}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberColors.TextPrimary
                    )
                    if (item.isFromScreenScanner) {
                        Text(
                            text = "SCANNER",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberColors.CyberCyan,
                            modifier = Modifier
                                .background(CyberColors.CyberCyan.copy(alpha = 0.14f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.assetSymbol} • ${item.timeframeCode} • Entry ${Formatters.formatPrice(item.entryPrice, item.priceDecimals)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberColors.TextPrimary
                )
                Text(
                    text = Formatters.formatDateTime(item.timestampMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberColors.TextMuted
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.outcome,
                    style = MaterialTheme.typography.labelSmall,
                    color = outcomeColor,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .border(1.dp, outcomeColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                )
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Toggle analysis details",
                        tint = CyberColors.TextSecondary
                    )
                }
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Text("TREND: ${item.trendDirection} • EXPIRY: ${item.suggestedExpiryMinutes}m", style = MaterialTheme.typography.labelSmall, color = CyberColors.CyberCyan)
                Spacer(modifier = Modifier.height(6.dp))
                Text(item.detailedAnalysis, style = MaterialTheme.typography.bodySmall, color = CyberColors.TextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                Text("LOCAL: ${item.localSummary}", style = MaterialTheme.typography.labelSmall, color = CyberColors.TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("GEMINI: ${item.geminiSummary}", style = MaterialTheme.typography.labelSmall, color = CyberColors.TextSecondary)

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onVerifyOutcome(SignalOutcome.WIN) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberColors.NeonGreen)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WIN", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = { onVerifyOutcome(SignalOutcome.LOSS) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberColors.PutCrimson)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("LOSS", style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete record", tint = CyberColors.TextMuted)
                    }
                }
            }
        }
    }
}
